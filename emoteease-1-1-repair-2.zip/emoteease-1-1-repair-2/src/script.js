// Splash Screen Navigation
function navigateToWelcome() {
    document.getElementById('splash-screen').style.display = 'none';
    document.getElementById('welcome-section').style.display = 'block';
}

function navigateToMain() {
    document.getElementById('welcome-section').style.display = 'none';
    document.getElementById('main-content').style.display = 'block';
}

// Mood Tracker Interactions
function selectEmoji(button) {
    const emojiQuestion = document.getElementById('emoji-question');
    const ratingQuestion = document.getElementById('rating-question');
    const selectedEmoji = button.textContent;

    // Remove active class from all buttons and add it to the selected button
    document.querySelectorAll('#emoji-options button').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');

    emojiQuestion.setAttribute('data-selected-emoji', selectedEmoji);
    ratingQuestion.style.display = 'block';
}

function showFactorsQuestion() {
    const rating = document.getElementById('mood-rating').value;
    if (rating >= 1 && rating <= 10) {
        document.getElementById('factors-question').style.display = 'block';
        document.getElementById('save-button').style.display = 'block';
    }
}

function analyzeMood() {
    // Show loading message
    document.getElementById('mood-summary').innerText = "Analyzing your mood...";
    document.getElementById('mood-suggestions').innerText = "";
    document.getElementById('mood-analysis').style.display = 'block';

    // Introduce a delay of 5 seconds before displaying the analysis
    setTimeout(() => {
        const selectedEmojiButton = document.querySelector('#emoji-options button.active');
        const emoji = selectedEmojiButton ? selectedEmojiButton.innerText : '';
        const rating = parseInt(document.getElementById('mood-rating').value, 10);
        const factors = document.getElementById('mood-factors').value;

        let summary = '';
        let suggestions = '';

        if (emoji === '😊') {
            if (rating >= 1 && rating <= 3) {
                summary = "You feel sad but are hiding your feelings.";
                suggestions = "Try to open up to someone you trust.";
            } else if (rating >= 4 && rating <= 7) {
                summary = "You feel calm.";
                suggestions = "Maintain your calmness by engaging in relaxing activities.";
            } else {
                summary = "You feel grateful.";
                suggestions = "Keep up the positive attitude!";
            }
        } else if (emoji === '😔') {
            if (rating >= 1 && rating <= 3) {
                summary = "You are feeling satisfied yet sad.";
                suggestions = "Reflect on what's causing your sadness and seek support if needed.";
            } else if (rating >= 4 && rating <= 7) {
                summary = "You are feeling unmotivated.";
                suggestions = "Try to find small tasks that can boost your motivation.";
            } else {
                summary = "You are feeling pessimistic and need to chill.";
                suggestions = "Take a break and focus on self-care.";
            }
        } else if (emoji === '😡') {
            if (rating >= 1 && rating <= 3) {
                summary = "You are feeling annoyed but still easygoing.";
                suggestions = "Identify the source of annoyance and address it calmly.";
            } else if (rating >= 4 && rating <= 7) {
                summary = "You are feeling tense but still optimistic.";
                suggestions = "Engage in activities that reduce stress.";
            } else {
                summary = "You are feeling really frustrated and need to relax.";
                suggestions = "Take deep breaths and practice mindfulness.";
            }
        } else if (emoji === '😴') {
            if (rating >= 1 && rating <= 3) {
                summary = "You are feeling sleepy.";
                suggestions = "Ensure you get enough rest.";
            } else if (rating >= 4 && rating <= 7) {
                summary = "You are feeling restful and unmotivated.";
                suggestions = "Use this time to recharge and set new goals.";
            } else {
                summary = "You are feeling tranquil but bored.";
                suggestions = "Find a new hobby or activity to engage in.";
            }
        } else if (emoji === '😍') {
            if (rating >= 1 && rating <= 3) {
                summary = "You are feeling joyful.";
                suggestions = "Spread your joy to others.";
            } else if (rating >= 4 && rating <= 7) {
                summary = "You are feeling pleased.";
                suggestions = "Keep up the good mood!";
            } else {
                summary = "You are feeling enthusiastic and lively.";
                suggestions = "Channel your energy into productive activities.";
            }
        }

        document.getElementById('mood-summary').innerText = summary;
        document.getElementById('mood-suggestions').innerText = suggestions;

        openModal(summary, suggestions);
    }, 5000); // 5 second delay
}

function saveMood() {
    const name = document.getElementById('user-name').value;
    const date = new Date().toLocaleDateString();
    const emoji = document.getElementById('emoji-question').getAttribute('data-selected-emoji');
    const rating = document.getElementById('mood-rating').value;
    const factors = document.getElementById('mood-factors').value;
    const summary = document.getElementById('mood-summary').textContent;

    const table = document.getElementById('mood-record-table').querySelector('tbody');
    const newRow = table.insertRow();
    newRow.insertCell(0).textContent = name;
    newRow.insertCell(1).textContent = date;
    newRow.insertCell(2).textContent = emoji;
    newRow.insertCell(3).textContent = rating;
    newRow.insertCell(4).textContent = factors;
    newRow.insertCell(5).textContent = summary;

    document.getElementById('mood-records').style.display = 'block';

    // Clear input fields after saving
    document.getElementById('user-name').value = '';
    document.getElementById('mood-rating').value = '';
    document.getElementById('mood-factors').value = '';
    document.getElementById('emoji-question').removeAttribute('data-selected-emoji');
    document.getElementById('rating-question').style.display = 'none';
    document.getElementById('factors-question').style.display = 'none';
    document.getElementById('save-button').style.display = 'none';
    document.getElementById('mood-analysis').style.display = 'none';
}

// Modal Interactions
function openModal(summary, suggestions) {
    document.getElementById('moodModal').style.display = 'block';
    document.getElementById('modal-summary').innerText = summary;
    document.getElementById('modal-suggestions').innerText = suggestions;
}

function closeModal() {
    document.getElementById('moodModal').style.display = 'none';
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('start-button');
    const continueButton = document.getElementById('continue-button');
    const closeButton = document.querySelector('.close');

    if (startButton) {
        startButton.addEventListener('click', navigateToWelcome);
    }

    if (continueButton) {
        continueButton.addEventListener('click', navigateToMain);
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeModal);
    }
});

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('splash-screen').style.display = 'flex';
});

function showQuotesSection() {
    closeModal();
    window.location.hash = '#quotes';
}

// Mindfulness Meditation
function playMindfulnessMeditation() {
    // Show the mindfulness meditation section
    document.getElementById('mindfulness-game').style.display = 'block';
}

function openGratefulHeartDiary() {
    // Show the Grateful Heart Diary section
    document.getElementById('grateful-diary').style.display = 'block';
}

function startEmotionalCheckIn() {
    alert("Starting Emotional Check-In...");
}

function beginCBT() {
    alert("Beginning Cognitive Behavioral Therapy (CBT)...");
}

function practicePositiveAffirmations() {
    alert("Starting Positive Affirmations...");
}

// Mindfulness Meditation Functions
(function() {
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    }

    window.startMeditation = function() {
        const durationSelect = document.getElementById('meditation-duration');
        const soundSelect = document.getElementById('meditation-sound');
        const meditationTimer = document.getElementById('meditation-timer');
        const timerDisplay = document.getElementById('timer-display');

        let duration = parseInt(durationSelect.value) * 60; // Convert minutes to seconds
        let remainingTime = duration;

        // Show the meditation timer
        meditationTimer.style.display = 'block';

        // Play the selected sound
        const selectedSound = document.getElementById(soundSelect.value);
        if (selectedSound) {
            selectedSound.play();
            selectedSound.loop = true; // Loop the sound
        }

        const updateTimer = () => {
            timerDisplay.textContent = formatTime(remainingTime);

            if (remainingTime <= 0) {
                clearInterval(timerInterval);
                showMeditationEndModal();
                if (selectedSound) {
                    selectedSound.pause();
                    selectedSound.currentTime = 0; // Reset the sound
                }
            } else {
                remainingTime--;
            }
        };

        const timerInterval = setInterval(updateTimer, 1000);

        updateTimer();
    }

    function showMeditationEndModal() {
        const meditationEndModal = document.getElementById('meditation-end-modal');
        meditationEndModal.style.display = 'block';
    }

    window.closeMessage = function() {
        const messageBar = document.getElementById('message-bar');
        messageBar.style.display = 'none';
    }

    window.closeMeditationEndModal = function() {
        const meditationEndModal = document.getElementById('meditation-end-modal');
        meditationEndModal.style.display = 'none';
    }

    window.onclick = function(event) {
        const meditationEndModal = document.getElementById('meditation-end-modal');
        if (event.target == meditationEndModal) {
            meditationEndModal.style.display = 'none';
        }
    };
})();

// Grateful Heart Diary Functions
function getEntries() {
    const entries = localStorage.getItem('gratitudeEntries');
    return entries ? JSON.parse(entries) : [];
}

document.addEventListener('DOMContentLoaded', () => {
    const newEntryButton = document.getElementById('newEntryButton');
    const viewEntriesButton = document.getElementById('viewEntriesButton');
    const newEntryForm = document.getElementById('newEntryForm');
    const saveEntryButton = document.getElementById('saveEntryButton');
    const gratitudeText = document.getElementById('gratitudeText');
    const gratitudeImage = document.getElementById('gratitudeImage');
    const entriesListScreen = document.getElementById('entriesListScreen');
    const entriesList = document.getElementById('entriesList');
    const backToHomeFromEntries = document.getElementById('backToHomeFromEntries');
    const viewEntryScreen = document.getElementById('viewEntryScreen');
    const viewEntryContent = document.getElementById('viewEntryContent');
    const editEntryButton = document.getElementById('editEntryButton');
    const deleteEntryButton = document.getElementById('deleteEntryButton');
    const backToEntries = document.getElementById('backToEntries');
    const quote = document.getElementById('quote');

    let currentEntryIndex = null;

    const quotes = [
        "Gratitude turns what we have into enough.",
        "The more you practice gratitude, the more you see how much there is to be grateful for.",
        "Gratitude is the fairest blossom which springs from the soul.",
        "Gratitude makes sense of our past, brings peace for today, and creates a vision for tomorrow."
    ];

    quote.innerText = quotes[Math.floor(Math.random() * quotes.length)];

    newEntryButton.addEventListener('click', () => {
        newEntryForm.classList.remove('hidden');
        entriesListScreen.classList.add('hidden');
        viewEntryScreen.classList.add('hidden');
    });

    viewEntriesButton.addEventListener('click', () => {
        displayEntries();
        entriesListScreen.classList.remove('hidden');
        newEntryForm.classList.add('hidden');
        viewEntryScreen.classList.add('hidden');
    });

    saveEntryButton.addEventListener('click', () => {
        const text = gratitudeText.value.trim();
        const image = gratitudeImage.files[0];
        if (text || image) {
            const entry = {
                date: new Date().toLocaleDateString(),
                text: text,
                image: image ? URL.createObjectURL(image) : null
            };
            saveEntry(entry);
            gratitudeText.value = '';
            gratitudeImage.value = '';
        }
    });

    function displayEntries() {
        const entries = getEntries();
        entriesList.innerHTML = '';
        entries.forEach((entry, index) => {
            const entryDiv = document.createElement('div');
            entryDiv.className = 'entry';
            entryDiv.innerHTML = `
                <div class="entry-date">${entry.date}</div>
                <div class="entry-text">${entry.text.split('\n')[0]}</div>
                <button onclick="viewEntry(${index})">View</button>
            `;
            entriesList.appendChild(entryDiv);
        });
    }

    window.viewEntry = (index) => {
        const entry = getEntries()[index];
        currentEntryIndex = index;
        viewEntryContent.innerHTML = `
            <div class="entry-date">${entry.date}</div>
            <div class="entry-text">${entry.text}</div>
            ${entry.image ? `<img src="${entry.image}" class="entry-image" alt="Gratitude Image">` : ''}
        `;
        viewEntryScreen.classList.remove('hidden');
        entriesListScreen.classList.add('hidden');
        newEntryForm.classList.add('hidden');
    };

    editEntryButton.addEventListener('click', () => {
        const entries = getEntries();
        const entry = entries[currentEntryIndex];
        gratitudeText.value = entry.text;
        gratitudeImage.value = '';
        newEntryForm.classList.remove('hidden');
        viewEntryScreen.classList.add('hidden');
    });

    deleteEntryButton.addEventListener('click', () => {
        const entries = getEntries();
        entries.splice(currentEntryIndex, 1);
        localStorage.setItem('gratitudeEntries', JSON.stringify(entries));
        currentEntryIndex = null;
        displayEntries();
        viewEntryScreen.classList.add('hidden');
        entriesListScreen.classList.remove('hidden');
    });

    backToEntries.addEventListener('click', () => {
        viewEntryScreen.classList.add('hidden');
        entriesListScreen.classList.remove('hidden');
    });

    backToHomeFromEntries.addEventListener('click', () => {
        entriesListScreen.classList.add('hidden');
        newEntryForm.classList.add('hidden');
    });

    displayEntries();
});

function saveEntry(entry) {
    let entries = getEntries();
    entries.push(entry);
    localStorage.setItem('gratitudeEntries', JSON.stringify(entries));
}

// Quran Corner Functions
document.addEventListener('DOMContentLoaded', () => {
    const verses = [
        'Indeed, Allah is with the patient. (2:153)',
        'And We have certainly made the Qur\'an easy for remembrance, so is there any who will remember? (54:17)',
        'So remember Me; I will remember you. And be grateful to Me and do not deny Me. (2:152)',
    ];

    const dailyVerseElement = document.getElementById('verse-text');
    const randomVerse = verses[Math.floor(Math.random() * verses.length)];
    dailyVerseElement.textContent = randomVerse;
});

function showSection(sectionId) {
    const sections = document.querySelectorAll('.container');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

function goBack() {
    const mainPage = document.getElementById('main-page');
    const sections = document.querySelectorAll('.container');
    sections.forEach(section => {
        if (section !== mainPage) {
            section.style.display = 'none';
        }
    });
    mainPage.style.display = 'block';
}
